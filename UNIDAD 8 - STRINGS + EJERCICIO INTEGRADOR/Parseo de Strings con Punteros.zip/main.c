#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


/**
    Guardar en un vector datos ingresados por el usuario.
    Cada ingreso comenzar� con el nombre de una magnitud, a
    continuaci�n tendr� el s�mbolo "=" y luego el valor correspondiente.

    Ejemplo de datos a ingresar por teclado:
        Temperatura[�C]=25
        Peso[Kgr]=10
        Superficie[m2]=2
        Tension[Volt]=220

    Parsear el string ingresado e imprimir por pantalla el valor
**/
int main()
{
    char vector1[30];
    char *ptrVector1 = vector1;
    int largo1;
    char valor[10];
    char *ptrValor = valor;
    int signoIgual = 0;
    //int j = 0;
    int valorEntero = 0;


    printf("Ingrese nombre de magnitud, luego el simbolo = y el valor. Ejemplo Tension[Volt]=220: ");
    gets(vector1);
    printf("Vector 1: %s \n",vector1);

    largo1 = strlen(vector1);
    printf("Largo del vector 1: %d \n",largo1);

    for(int i=0; i<largo1; i++)
    {
        //if(vector1[i] ==  '=')
        if(*ptrVector1 ==  '=')
        {
            // Cuento la cantidad de "=" encontrados
            signoIgual++;

            printf("Signo = encontrado\n");
        }
        if(signoIgual == 1)
        {
            // Copio caracter a caracter la cantidad que aparece a la derecha del =
            //valor[j] = vector1[i+1];
            //j++;
            *ptrValor = *(ptrVector1+1);
            ptrValor++;
        }
        ptrVector1++;
    }

    // Convierto el valor de String a Entero
    valorEntero = atoi(valor);
    printf("El valor en formato Entero es: %d \n",valorEntero);

    return 0;
}
