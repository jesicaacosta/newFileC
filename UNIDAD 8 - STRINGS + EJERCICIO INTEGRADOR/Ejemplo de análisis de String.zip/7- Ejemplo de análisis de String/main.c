#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


/**
    guardar en vector1 nombre, apellido, dni y peso separados por un guion medio.

    Ejemplos de vector1:

    Juan-Perez-54564564-74.1

    Juan-Martinez-564564564-85.6

    Dividir los datos y guardarlos:
        vector2: nombre
        vector3: apellido
        vector4: dni
        vector5: peso


    imprimir los vectores 1, 2, 3, 4 y 5 para validar.
**/
int main()
{
    char vector1[30];
    char vector2[30];
    char vector3[30];
    char vector4[30];
    char vector5[30];

    int largo1;
    int cont =0;
    int largo2, largo3;
    int Guiones = 0;
    int DNIEntero = 0;
    float pesoFloat = 0.0;
    int j = 0;

    printf("Ingrese nombre, apellido, DNI y peso separados por un guion medio ( - ): ");
    gets(vector1);
    printf("Vector 1: %s \n",vector1);

    largo1 = strlen(vector1);
    printf("Largo del vector 1: %d \n",largo1);

    for (int i=0; i<largo1; i++)
    {
        if(vector1[i]=='-')
        {
            cont++;
        }
        else if (cont == 0){
            vector2[i] = vector1[i];
            vector2[i+1] = '\0';
            //cada vez que agrego una letra al vector, pongo el centinela \0 una posicion delante
        }
        else if (cont == 1)
        {
            largo2 = strlen(vector2);
            vector3[i-largo2-cont] = vector1[i];
            vector3[i-largo2-cont+1] = '\0';
        }
        else if (cont ==2)
        {
            largo3 = strlen(vector3);
            vector4[i-largo2-largo3-cont] = vector1[i];
            vector4[i-largo2-largo3-cont+1] = '\0';
        }
    }

    printf("Nombre: %s \n",vector2);
    printf("Apellido: %s \n",vector3);
    printf("DNI: %s \n",vector4);

    // Utilizo otra forma para buscar el peso que est� a la derecha del tercer gui�n "-"
    for(int i=0; i<largo1; i++)
    {
        if(vector1[i] ==  '-')
        {
            // Cuento la cantidad de "guiones" encontrados
            Guiones++;
        }
        if(Guiones == 3)
        {
            // Copio caracter a caracter la cantidad que aparece a la derecha del tercer gui�n
            vector5[j] = vector1[i+1];
            j++;
        }
    }

    // Convierto el peso de String a float
    pesoFloat = atof(vector5);
    printf("Peso en formato float: %.1f \n",pesoFloat);

    // Convierto el DNI de String a int
    DNIEntero = atoi(vector4);
    printf("DNI en formato int: %i \n",DNIEntero);

    return 0;
}




