#include <stdio.h>
#include <stdlib.h>

//similitud entre arrays y punteros

//Observar detenidamente como cargamos datos en el scanf utilizando ambos metodos.


int main()
{
    int v[5];

    printf("Llenamos el vector de la forma clasica:\n");
    for(int i=0;i<5;i++)
    {
        scanf("%d",&v[i]); // notar que de esta forma, necesitamos el &, para darle la direccion de memoria a scanf
    }

    printf("Imprimimos el vector con aritmetica de vectores\n");
    for (int i=0; i<5; i++)
    {
        //imprimimos nuestro vector con aritmetica de vector
        printf("%d) %d\n",i,v[i]);
    }

    printf("\nImprimimos el vector con aritmetica de punteros\n");
    for (int i=0; i<5; i++)
    {
        //imprimimos nuestro vector con aritmetica de punteros
        printf("%d) %d\n",i,*(v+i));
    }

    //Ahora creamos un vector pero con aritmetica de punteros

    int *v2 = malloc(5*sizeof(int)); //Reservamos memoria para 5 veces el tamanio de un int

    printf("\n Llenamos el nuevo vector con la aritmetica de punteros:\n");
    for (int i=0;i<5;i++)
    {
        scanf("%d",(v2+i)); //notar que no utilizamos &, ya que scanf funciona con direcciones de memoria
    }

    printf("Imprimimos el vector con aritmetica de vectores\n");
    for (int i=0; i<5; i++)
    {
        //imprimimos nuestro vector con aritmetica de vector
        printf("%d) %d\n",i,v2[i]);
    }

    printf("\nImprimimos el vector con aritmetica de punteros\n");
    for (int i=0; i<5; i++)
    {
        //imprimimos nuestro vector con aritmetica de punteros
        printf("%d) %d\n",i,*(v2+i));
    }
    return 0;
}
