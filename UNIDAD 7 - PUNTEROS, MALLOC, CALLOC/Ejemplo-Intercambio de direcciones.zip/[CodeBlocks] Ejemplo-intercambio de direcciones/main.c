#include <stdio.h>
#include <stdlib.h>

int main()
{
int *a = malloc(sizeof(int)); //creo un puntero a entero, y le asigno memoria suficiente para ese tipo de dato
int *b = malloc(sizeof(int)); // idem
int *temp; //creo un puntero a entero, por el momento vacio

*a = 5; //guardo el valor 5, en la direccion de memoria que tiene guardado el puntero a
*b = 10; //idem, con b
printf("a: %d\n",*a); //imprimo lo apuntado por a, para verificar
printf("b: %d\n",*b); //idem
temp = a;
// como temp, y a, son punteros, puedo igualarlos sin problema...
//ahora temp apunta a donde apunta "a"
a = b; // a apunta a donde apunta b
b = temp; //b apunta a donde apunta temp, que es donde apuntaba a originalmente

//ahora volvemos a imprimir nuestras variables, y observamos los cambios
printf("\n luego del intercambio de direcciones:\n");
printf("a: %d\n",*a); //imprimo lo apuntado por a, para verificar
printf("b: %d\n",*b); //idem
    return 0;
}
