#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "alumno.h"

#define MAX_ALUMNOS 100

int main()
{
    int opcionMenu;
    bool seguir = true;
    int cant_alumnos = 0;

    // ptr_nodo_t es un Puntero a estructura. Entonces alumno ser� un puntero que apuntar� a una estructura del tipo nodo.
    ptr_nodo_t alumno;

    // vector es un array de punteros a estructuras del tipo nodo.
    ptr_nodo_t vector[MAX_ALUMNOS];

    enum menuOpciones {Agregar=1, Listar, Salir};

    while (seguir)
    {
        // Men� de opciones
        printf("\n1- Agregar Alumno\n");
        printf("2- Listar Alumnos\n");
        printf("3- Salir\n");
        scanf("%d",&opcionMenu);

        switch(opcionMenu){
            case Agregar:
                if (cant_alumnos < MAX_ALUMNOS) {
                    // Con la funci�n ingresar_alumno reservo memoria para una nueva estructura. Retornar� el puntero a la nueva estructura creada.
                    alumno = ingresar_alumno();
                    if (alumno) {
                        // Si no devolvi� NULL, almaceno en el vector de punteros la direcci�n de la posici�n de memoria del comienzo de la nueva estructura creada
                        vector[cant_alumnos] = alumno;
                        cant_alumnos++;
                    }
                }
                else {
                    printf("\nNo hay lugar para mas alumnos\n");
                }

                break;

            case Listar:
                for (int i = 0 ; i < cant_alumnos ; i++) {
                    // Paso como par�metro el puntero (direcci�n de memoria) de la estructura a imprimir.
                    imprimir_alumno(vector[i]);
                }
                break;

            case Salir:
                seguir =false;
                break;

            default:
                printf("Error, opcion invalida\n\n");
        }
    }
    return 0;
}

