#ifndef ALUMNO_H_INCLUDED
#define ALUMNO_H_INCLUDED

//ptr_nodo_t = struct nodo *: ptr_nodo_t es un Puntero a Estructura del tipo nodo.
typedef struct nodo * ptr_nodo_t;

//declaracion de la estructura
struct nodo {
        int edad;
        int legajo;
        float promedio;
};

// Funcion que retorna un puntero a estructura
ptr_nodo_t ingresar_alumno(void);

// Funcion que recibe como par�metro un puntero a estructura
void imprimir_alumno(ptr_nodo_t alumno);

#endif // ALUMNO_H_INCLUDED
