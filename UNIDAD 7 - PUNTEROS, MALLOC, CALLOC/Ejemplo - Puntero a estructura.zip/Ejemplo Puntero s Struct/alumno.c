#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "alumno.h"

// La siguiente funci�n devuelve un puntero a estructura del tipo nodo (ptr_nodo_t)
ptr_nodo_t ingresar_alumno()
{
    // Para agregar un alumno necesito pedir memoria para alojar los datos correspondientes.
    // Con malloc pido la memoria necesaria para alojar una estructura.
    // sizeof me calcula la cantidad de bytes que ocupa la estructura.
    ptr_nodo_t nuevo_alumno = malloc(sizeof(*nuevo_alumno));

    // Verifico que malloc no haya devuelto NULL
    if (nuevo_alumno)
    {
        // malloc no devolvi� NULL: pudo reservar memoria
        printf("Ingrese edad: ");
        scanf("%d", &nuevo_alumno->edad);
        printf("Ingrese legajo: ");
        scanf(" %d", &nuevo_alumno->legajo);
        printf("Ingrese promedio: ");
        scanf(" %f", &nuevo_alumno->promedio);
    }
    else
        printf ("\n--- ERROR: no hay memoria disponible !!!\n");

    // Retorno el puntero a la estructura nueva que se cre�
    return nuevo_alumno;
}

void imprimir_alumno(ptr_nodo_t alumno)
{
    printf("\nEdad : %d\nLegajo: %d\nPromedio %4.2f\n",
           alumno->edad, alumno->legajo, alumno->promedio);
}




