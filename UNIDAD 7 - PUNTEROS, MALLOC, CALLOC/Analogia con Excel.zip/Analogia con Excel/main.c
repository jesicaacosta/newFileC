#include <stdio.h>
#include <stdlib.h>

#define TAM 10

// Analog�a entre Excel, arrays y punteros

int main()
{
    int Vect[TAM] = {5, 11, 15, 24, 1, 4, 555, 2, 3, 1111};
    int *puntero;
    printf("Imprimimos posiciones del vector con aritmetica de vectores\n");
    printf("%d\n",Vect[0]);
    printf("%d\n",Vect[1]);
    printf("%d\n",Vect[9]);
    // Imprimo la suma de 2 posiciones del vector
    printf("%d\n",Vect[1]+Vect[9]);

    // Apunto el puntero al comienzo del vector
    puntero = Vect;
    printf("Imprimimos posiciones del vector con aritmetica de punteros\n");
    printf("%d\n",*puntero);
    printf("%d\n",*(puntero+1));
    printf("%d\n",*(puntero+9));
    // Imprimo la suma de 2 posiciones del vector
    printf("%d\n",*(puntero+1)+*(puntero+9));

    // Apunto el puntero al comienzo del vector usando &
    puntero = &Vect[0];
    printf("Imprimimos posiciones del vector con aritmetica de punteros\n");
    printf("%d\n",*puntero);
    printf("%d\n",*(puntero+1));
    printf("%d\n",*(puntero+9));
    // Imprimo la suma de 2 posiciones del vector
    printf("%d\n",*(puntero+1)+*(puntero+9));
    return 0;
}
