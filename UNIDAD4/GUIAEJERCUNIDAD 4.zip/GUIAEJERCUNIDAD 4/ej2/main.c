#include <stdio.h>
#include <stdlib.h>

int main()
{
    //2. Escribir un programa que emita por pantalla el abecedario. (Ayudarse con la tabla ASCII).
    for (int i =97 ;i <123; i++) {
            printf ("%c\n" ,i );
    }

    return 0;
}
