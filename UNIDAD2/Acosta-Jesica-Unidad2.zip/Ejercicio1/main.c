#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf ("\t Casa con ASCII \n\n");

    printf("\t      /\\ ---------------------- \\  \n");
    printf("\t     /  \\ ---------------------- \\  \n");
    printf("\t    /    \\ ---------------------- \\ \n");
    printf("\t   /  0   \\ ---------------------- \\ \n");
    printf("\t  / *****  \\ ---------------------- \\ \n");
    printf("\t /__________\\ ---------------------- \\ \n");
    printf("\t  |   __   ||             _____      | \n");
    printf("\t  |  |  |  ||         ***|_____|***  | \n");
    printf("\t  |  |  |  ||                        | \n");
    printf("\t  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ \n\n\n");


    printf ("\tGato con ASCII \n\n");
    printf("\t  /\\--/\\      \n");
    printf("\t ( ^  ^ )     \n");
    printf("\t ('')('')     \n");
}
