#include <stdio.h>
#include <stdlib.h>

int main()
{
//Formato profesional - Impresi�n en Columnas

    printf("POSICI%cN\tGANANCIA\t\t%cREA INCREMENTAL \t \n",224,181);
    printf("%d\t\t%.1f\t\t\t%.10f \n", -1 , -3.0, 12.0123456789);
    printf("%d\t\t%.1f\t\t\t%.10f \n", 1, 64.55, 2.444444444);
    printf("%d\t\t%.1f\t\t\t%.10f \n", 13, 333.52, -87.987654321);


    return 0;
}
