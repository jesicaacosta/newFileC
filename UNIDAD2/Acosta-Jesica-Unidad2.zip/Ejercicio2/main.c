#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Formato profesional - Ascii extendido \n\n");
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c \n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c \n",186,32,32,32,32,83,73,83,84,69,77,65,32,68,69,32,32,32,32,32,32,186);
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c \n",186,32,32,32,32,32,32,71,69,83,84,73,224,78,32,32,32,32,32,32,32,186);
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c \n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);

    return 0;
}
