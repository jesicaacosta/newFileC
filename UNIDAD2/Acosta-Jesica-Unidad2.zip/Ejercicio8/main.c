#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c \n",186,32,32,32,70,79,82,77,65,84,69,65,82,32, 70,69,67,72,65,32,32,32,186);
    printf("\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);


    int fecha, anio;
    char mes;

    printf("\n\nIngrese la fecha: \n");
    scanf ("%d", &fecha);

    printf("Ingrese el mes: \n");
    scanf ("%d", &mes);


    printf("Ingrese el a%c: \n",164);
    scanf ("%d", &anio);

    printf("Ingreso: %d-%d-%d", fecha, mes, anio);


    return 0;
}
