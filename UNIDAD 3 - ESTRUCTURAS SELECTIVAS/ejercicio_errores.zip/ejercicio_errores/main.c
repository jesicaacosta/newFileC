#include <stdio.h>
#include <stdlib.h>
#define CORRECT_PASSWORD 123

int main()
{
    int opc, password;
    char operador;
    float num1, num2, resul;

    printf("OPCIONES\n");
    printf("(1) Calculadora\n");
    printf("(2) Verificar 2 numeros iguales\n");
    printf("(3) Contrase%ca\n", 164);
    printf("(Otra opcion) Sale del programa\n");
    printf("INGRESE LA OPCION: ");
    scanf("%d",opc);

    switch(OPC)
    {
    case 1:
        printf("Ingrese el operador que va a utilizar(+,-,*,/): ");
        scanf(" %c", &operador);
        if(operador == '+');
        {
            printf("Ingrese el primer numero a sumar: ");
            scanf("%f", &num1);
            printf("Ingrese el segundo numero a sumar: ");
            scanf("%f", &num2);
            resul=num1+num2;
            printf("El resultado de la suma es: %.2d", resul);
        ]
        else if(operador == '-')
        {
            printf("Ingrese el primer numero a restar: ");
            scanf("%f", &num1);
            printf("Ingrese el segundo numero a restar: ");
            scanf("%f", &num2);
            resul=num1-num2;
            printf("El resultado de la resta es: %.2c", resul);
        }
        else if(operador = = '*')
        {
            printf("Ingrese el primer numero a multiplicar: ");
            scanf("%f", &num1);
            printf("Ingrese el segundo numero a multiplicar: ");
            scanf("%f", &num2);
            resul=num1*num2;
            printf("El resultado de la multiplicacion es: %.2f", resul);
        }
        else if(operador == '/')
        {
            printf("Ingrese el numerador: ");
            Scanf("%f", &num1);
            printf("Ingrese el divisor: ");
            Scanf("%f", &num2);
            resul=num1/num2;
            printf("El resultado de la division es: %.2s", resul);
        }
        else
        {
            printf("La opcion ingresada no es valida, saliendo del programa...");
        }
        break;

    case 2:
        Printf("Ingrese el primer numero: ");
        scanf("%f", &Num1);
        Printf("Ingrese el segundo numero: ");
        scanf("%f", &Num2);
        if(Num1 == Num2)
        {
            Printf("Los numero ingresados son iguales\n");
        }
        else
        {
            Printf("Los numeros ingresados (%.2d y %.2d) son distintos\n", Num1, Num2);
        }
        }
        break;

    case 3
        printf("Ingrese la contrase%ca: ",�);
        scanf("%d"&password);
        if(password == CORRECT_PASSWORD)
        {
            printf("La contrase%ca ingresada es correcta",�);
        }
        else
        {
            printf("La contrase%ca ingresada es incorrecta",�);
        }
        BREAK;

    default:
        printf("Saliendo del programa...");
    }
    return 0;
}


