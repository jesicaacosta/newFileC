#include <stdio.h>

int main()
{
    int res_arg, res_fra;
    int res_ala_arg, res_al_fra;
    int res_pen_arg, res_pen_fra;

    printf("Ingrese el resultado de Argentina: ");
    scanf("%d", &res_arg);
    printf("Ingrese el resultado de Francia: ");
    scanf("%d", &res_fra);

    if (res_arg > res_fra)
    {
        printf("Argentina es Campeon del Mundooo!!!!!!! Llegó la tercera!!\n");
    }
    else if (res_arg < res_fra)
    {
        printf("Gano Francia.\n");
    }
    else
    {
        printf("Empate en los primeros 90 minutos, se juega alargue.\n");
        printf("Ingrese el resultado de Argentina en el alargue: ");
        scanf("%d", &res_ala_arg);
        printf("Ingrese el resultado de Francia en el alargue: ");
        scanf("%d", &res_al_fra);

        if (res_ala_arg > res_al_fra)
        {
            printf("Argentina es Campeon Mundial en el alargue!!!!\n");
            printf("¡¡¡Se ha sufrido demasiado para obtener la tercer estrella!!!!\n");
        }
        else if (res_ala_arg < res_al_fra)
        {
            printf("Gano Francia en el alargue.\n");
        }
        else
        {
            printf("Empate en el alargue, se define por penales!! Por dios!!\n");
            printf("Ingrese el resultado de Argentina en los penales: ");
            scanf("%d", &res_pen_arg);
            printf("Ingrese el resultado de Francia en los penales: ");
            scanf("%d", &res_pen_fra);

            if (res_pen_arg > res_pen_fra)
            {
                printf("Argentina es Campeon del Mundo por penales!\n");
                printf("¡¡¡Se ha sufrido demasiado para obtener la tercer estrella!!!! \n");
            }
            else if (res_pen_arg < res_pen_fra)
            {
                printf("Francia es campeon por penales.\n");
            }
            else
            {
                printf("No se puede empatar en penales!\n");
            }
        }
    }
    return 0;
}
